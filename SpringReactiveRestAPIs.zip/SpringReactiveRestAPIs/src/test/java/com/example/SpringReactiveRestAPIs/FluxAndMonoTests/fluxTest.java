package com.example.SpringReactiveRestAPIs.FluxAndMonoTests;

import static org.junit.Assert.*;

import org.junit.Test;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class fluxTest {

	@Test
	public void fluxtest() {
		Flux<String> stringFlux = Flux.just("spring","springboot","spring reactive")
				.concatWith(Flux.error(new RuntimeException("Exception occured...")))
				.log();
		stringFlux.subscribe(System.out::println, (e)-> System.out.println(e));
		//StepVerifier.create(stringFlux).verifyComplete();
	}
	
	@Test
	public void fluxTest_withoutErrors(){
		Flux<String> stringFlux = Flux.just("spring","springboot","spring reactive")
				.log();
		StepVerifier.create(stringFlux)
		.expectNext("spring")
		.expectNext("springboot")
		.expectNext("spring reactive")
		.verifyComplete();
	}
	
	@Test
	public void fluxTest_withErrors(){
		Flux<String> stringFlux = Flux.just("spring","springboot","spring reactive")
				.concatWith(Flux.error(new RuntimeException("Exception********")))
				.log();
		StepVerifier.create(stringFlux)
		.expectNext("spring")
		.expectNext("springboot")
		.expectNext("spring reactive")
		//.expectError(RuntimeException.class)
		.expectErrorMessage("Exception********")
		.verify();
	}

	@Test
	public void fluxTestElementsCount_withErrors(){
		Flux<String> stringFlux = Flux.just("spring","springboot","spring reactive")
				.concatWith(Flux.error(new RuntimeException("Exception********")))
				.log();
		StepVerifier.create(stringFlux)
		.expectNextCount(3)
		//.expectError(RuntimeException.class)
		.expectErrorMessage("Exception********")
		.verify();
	}
	
	@Test
	public void fluxTest_withErrors1(){
		Flux<String> stringFlux = Flux.just("spring","springboot","spring reactive")
				.concatWith(Flux.error(new RuntimeException("Exception********")))
				.log();
		StepVerifier.create(stringFlux)
		.expectNext("spring","springboot","spring reactive")
		//.expectError(RuntimeException.class)
		.expectErrorMessage("Exception********")
		.verify();
	}
	
	
	@Test
	public void monoTest(){
		Mono<String> stringMono = Mono.just("Spring")
				.log();
		
		StepVerifier.create(stringMono)
			.expectNext("Spring")
			.verifyComplete();
	}
	
	@Test
	public void monoTest_Error(){
		
		StepVerifier.create(Mono.error(new RuntimeException("***ececption***")).log())
			.expectError(RuntimeException.class)
			.verify();
	}
}
