package com.example.SpringReactiveRestAPIs.FluxAndMonoTests;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

import org.junit.Test;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class FluxAndMonoFactoryTest {
	
	List<String> names =  Arrays.asList("adam", "anna", "jack", "rose");
	
	@Test
	public void fluxUsingIterable(){
		Flux<String> namesFlux = Flux.fromIterable(names)
				.log();
		
		StepVerifier.create(namesFlux)
		.expectNext("adam", "anna", "jack", "rose")
		.verifyComplete();
	}
	
	@Test
	public void fluxUsingArray(){
		String[] names = new String[]{"adam", "anna", "jack", "rose"};
		
		Flux<String> namesFlux = Flux.fromArray(names).log();

		StepVerifier.create(namesFlux)
		.expectNext("adam", "anna", "jack", "rose")
		.verifyComplete();
	}
	
	@Test
	public void fluxUsingStreams(){
		Flux<String> namesFlux = Flux.fromStream(names.stream()).log();
		
		StepVerifier.create(namesFlux)
		.expectNext("adam", "anna", "jack", "rose")
		.verifyComplete();
	}
	
	@Test
	public void monoUsigJustEmpty(){
		Mono<String> mono = Mono.justOrEmpty(null);
		
		StepVerifier.create(mono.log())
		.verifyComplete();
	}
	
	@Test
	public void monoUsingSupplier(){
		Supplier<String> stringSuppiler = () -> "adam";
		Mono<String> stringMono = Mono.fromSupplier(stringSuppiler);
		
		System.out.println(stringSuppiler.get());
		
		StepVerifier.create(stringMono.log())
		.expectNext("adam")
		.verifyComplete();
	}
	
	@Test
	public void fluxUsinngRange(){
		Flux<Integer> integerFlux = Flux.range(1, 5).log();
		
		StepVerifier.create(integerFlux)
		.expectNext(1,2,3,4,5)
		.verifyComplete();
	}
	
	@Test
	public void filterTestLength(){
		Flux<String> namesFlux = Flux.fromIterable(names)
				.filter(s -> s.length()>4)
				.log();
		
		StepVerifier.create(namesFlux)
		.expectNext("jenney")
		.verifyComplete();
	}
	
	

}
