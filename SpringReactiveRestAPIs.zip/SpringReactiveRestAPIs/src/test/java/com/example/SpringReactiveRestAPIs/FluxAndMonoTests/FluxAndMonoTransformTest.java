package com.example.SpringReactiveRestAPIs.FluxAndMonoTests;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

public class FluxAndMonoTransformTest {
	
	List<String> names = Arrays.asList("adam", "anna", "jack", "rose","jenney");

	@Test
	public void fluxTransformtest() {
		Flux<String> stringNames = Flux.fromIterable(names)
				.map(s -> s.toUpperCase())
				.log();
		StepVerifier.create(stringNames)
		.expectNext("ADAM", "ANNA", "JACK", "ROSE","JENNEY")
		.verifyComplete();
	}
	
	@Test
	public void fluxTransformtest_UsingMap_Filter() {
		Flux<String> stringNames = Flux.fromIterable(names)
				.filter(s -> s.length()>4)
				.map(s -> s.toUpperCase())
				.log();
		StepVerifier.create(stringNames)
		.expectNext("JENNEY")
		.verifyComplete();
	}
	
	@Test
	public void fluxTransformtest_Length() {
		Flux<Integer> stringNames = Flux.fromIterable(names)
				.map(s -> s.length())
				.log();
		StepVerifier.create(stringNames)
		.expectNext(4,4,4,4,6)
		.verifyComplete();
	}

	@Test
	public void fluxTransformtest_Length_repeat() {
		Flux<Integer> stringNames = Flux.fromIterable(names)
				.map(s -> s.length())
				.repeat(2)
				.log();
		StepVerifier.create(stringNames)
		.expectNext(4,4,4,4,6,4,4,4,4,6)
		.verifyComplete();
	}
}
